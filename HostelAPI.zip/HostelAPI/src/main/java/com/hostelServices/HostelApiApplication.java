package com.hostelServices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;

@SpringBootApplication
@OpenAPIDefinition(info=@Info(title="HostelServices",version="1.0",description="Provides Hostel Details Info"))
public class HostelApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HostelApiApplication.class, args);
	}

}
