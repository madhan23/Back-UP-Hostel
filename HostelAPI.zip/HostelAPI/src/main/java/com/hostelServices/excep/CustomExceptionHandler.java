package com.hostelServices.excep;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hostelServices.HostelServicesConstants;

@RestControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex, WebRequest request) {
		ErrorResponse error = new ErrorResponse(new Timestamp(System.currentTimeMillis()), ex.getMessage(),
				HostelServicesConstants.FAILURE);

		return new ResponseEntity<ErrorResponse>(error,
				error.getMessage().contains("JWT") ? HttpStatus.UNAUTHORIZED : HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(UserDetailException.class)
	public final  ResponseEntity<ErrorResponse> handleUserNotFoundException(UserDetailException ex, WebRequest request) {
		ErrorResponse error = new ErrorResponse(new Timestamp(System.currentTimeMillis()), ex.getMessage(),
				HostelServicesConstants.FAILURE);
	HttpStatus statusCode = getStatusCode(error.getMessage());
		return  new ResponseEntity<ErrorResponse>(error, statusCode);
	}

	@ExceptionHandler(HostelNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleHostelNotFoundException(HostelNotFoundException ex, WebRequest request) {
		ErrorResponse error = new ErrorResponse(new Timestamp(System.currentTimeMillis()), ex.getMessage(),
				HostelServicesConstants.FAILURE);
		HttpStatus statusCode = getStatusCode(error.getMessage());
		return  new ResponseEntity<ErrorResponse>(error, statusCode);
	}

	@Override
	protected final ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<String> errorDetails = new ArrayList<>();
		for (ObjectError error : ex.getBindingResult().getAllErrors()) {
			errorDetails.add(error.getDefaultMessage());
		}
		ErrorResponse error = new ErrorResponse(new Timestamp(System.currentTimeMillis()),
				HostelServicesConstants.FAILURE, errorDetails);
		return new ResponseEntity<Object>(error, HttpStatus.BAD_REQUEST);
	}

	private HttpStatus getStatusCode(String errorMessage) {
		HttpStatus statusCode = null;
		switch (errorMessage) {
		case HostelServicesConstants.NO_USERS_FOUND:
			statusCode = HttpStatus.NOT_FOUND;
			break;
		case HostelServicesConstants.INVALID_USER_ID:
			statusCode = HttpStatus.NOT_FOUND;
			break;				
		case HostelServicesConstants.INCORRECT_USERNAME_OR_PASSWORD:
			statusCode = HttpStatus.UNAUTHORIZED;
			break;
		case HostelServicesConstants.NO_HOSTELLIST_FOUND:
			statusCode = HttpStatus.NOT_FOUND;
			break;
		case HostelServicesConstants.AUTHORIZATION_HEADER:
			statusCode = HttpStatus.BAD_REQUEST;
			break;
		case HostelServicesConstants.INVALID_ROOM_DETAILS:
			statusCode = HttpStatus.NOT_FOUND;
			break;
		case HostelServicesConstants.INVALID_HOSTEL_DETAILS:
			statusCode = HttpStatus.NOT_FOUND;
		}
		return statusCode;
	}
}
