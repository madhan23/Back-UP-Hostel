package com.hostelServices.excep;

public class UserDetailException extends Exception {
	private static final long serialVersionUID = 145576888L;

	public UserDetailException(String message) {
		super(message);
	}


   
}
