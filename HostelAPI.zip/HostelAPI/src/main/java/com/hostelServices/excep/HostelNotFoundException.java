package com.hostelServices.excep;

public class HostelNotFoundException extends Exception {
	private static final long serialVersionUID = 15434356456L;

	public HostelNotFoundException(String message) {
		super(message);
	}
	
	

}
