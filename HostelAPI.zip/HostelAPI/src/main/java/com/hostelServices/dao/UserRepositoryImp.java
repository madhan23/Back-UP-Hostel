package com.hostelServices.dao;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hostelServices.HostelServicesConstants;
import com.hostelServices.excep.HostelNotFoundException;
import com.hostelServices.excep.UserDetailException;
import com.hostelServices.models.Hostel;
import com.hostelServices.models.RoomDetails;
import com.hostelServices.models.User;

@Repository
public class UserRepositoryImp {

	@Autowired
	UserRepository userRepository;

	@Autowired
	HostelRepository hostelRepository;

	@Autowired
	RoomRepository roomRepository;

	@Autowired
	EntityManager em;

	public List<User> getAllUser() {
		List<User> userList = (List<User>) userRepository.findAll();
		return userList;
	}

	public User getUser(long userId) throws UserDetailException {
		User user = userRepository.findById(userId).orElse(null);
		if (user == null)
			throw new UserDetailException(HostelServicesConstants.INVALID_USER_ID);

		return user;

	}

	public Hostel getHostelDetails(long hostelId) throws HostelNotFoundException {

		Hostel hostel = hostelRepository.findById(hostelId).orElse(null);
		if (hostel == null)
			throw new HostelNotFoundException(HostelServicesConstants.INVALID_HOSTEL_DETAILS);

		return hostel;

	}

	public List<Hostel> getHostelDetailsObj(long userId) throws UserDetailException {
		User user = getUser(userId);
		return user.getHostelList();

	}

	@Transactional
	public User addUserDetails(User user) {
		userRepository.save(user);
		return user;
	}

	@Transactional
	public Hostel hotelDetailEntry(long userId, Hostel hostel) throws UserDetailException {
		User user = getUser(userId);
		hostel.setUser(user);
		return hostelRepository.save(hostel);

	}

	@Transactional
	public Hostel hostelRoomDetailEntry(long userId, long hostelId, List<RoomDetails> roomDetailsList)
			throws UserDetailException, HostelNotFoundException {
		getUser(userId);
		Hostel hostel = getHostelDetails(hostelId);
		for (RoomDetails roomDetails : roomDetailsList) {
			roomDetails.setHostel(hostel);
			roomRepository.save(roomDetails);
		}

		return hostel;

	}

	@Transactional
	public Hostel hotelDetailUpdate(long userId, long hostelId, Hostel hostel)
			throws UserDetailException, HostelNotFoundException {
		User user = getUser(userId);
		Hostel hostelObj = getHostelDetails(hostelId);
		hostel.setUser(user);
		hostel.setRoomDetails(hostelObj.getRoomDetails());
		hostel.setHostelId(hostelId);

		return hostelRepository.save(hostel);

	}

	@Transactional
	public Hostel hostelRoomDetailUpdate(long userId, long hostelId, long roomId, RoomDetails roomDetails)
			throws UserDetailException, HostelNotFoundException {
	    getUser(userId);
		Hostel hostel = getHostelDetails(hostelId);
		RoomDetails roomInfoDetails = roomRepository.findById(roomId).orElse(null);
	
		
		
		if (roomInfoDetails == null)
			throw new HostelNotFoundException(HostelServicesConstants.INVALID_ROOM_DETAILS);
		
			roomDetails.setRoomId(roomId);
			roomDetails.setHostel(hostel);
			roomRepository.save(roomDetails);
		

		
		return hostel;
		
	}

	@Transactional
	public Hostel hostelRoomDetailDelete(long userId, long hostelId, long roomId)
			throws UserDetailException, HostelNotFoundException {
		getUser(userId);
		Hostel hostel = getHostelDetails(hostelId);

		RoomDetails roomInfoDetails = roomRepository.findById(roomId).orElse(null);

		if (roomInfoDetails == null)
			throw new HostelNotFoundException(HostelServicesConstants.INVALID_ROOM_DETAILS);

		roomRepository.deleteById(roomId);

		return hostel;

	}

	@Transactional
	public void removeHostelDetails(long userId, long hostelId) throws UserDetailException, HostelNotFoundException {
		getUser(userId);
		getHostelDetails(hostelId);
		hostelRepository.deleteById(hostelId);

	}

	public User userLogin(String mailId, String password) throws UserDetailException {

		Query query = em.createNamedQuery("LoginQuery", User.class);
		query.setParameter(1, mailId);
		query.setParameter(2, password);
		User user = (User) query.getSingleResult();
		if (user == null)
			throw new UserDetailException(HostelServicesConstants.INCORRECT_USERNAME_OR_PASSWORD);
		return user;
	}

}
