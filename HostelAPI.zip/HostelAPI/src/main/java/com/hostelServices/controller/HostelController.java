package com.hostelServices.controller;

import java.sql.Timestamp;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hostelServices.HostelServicesConstants;
import com.hostelServices.dto.ResponseDto;
import com.hostelServices.excep.HostelNotFoundException;
import com.hostelServices.excep.UserDetailException;
import com.hostelServices.models.Hostel;
import com.hostelServices.models.RoomDetails;
import com.hostelServices.models.User;
import com.hostelServices.services.UserServices;

@RestController
@RequestMapping("/hostel/api")
public class HostelController {
	@Autowired
	UserServices userservices;

	@PostMapping(value = "/user/login")
	private ResponseEntity<ResponseDto> userLogin(@RequestBody User user) throws UserDetailException {
		ResponseDto response = userservices.userLogin(user.getMailId(), user.getPassword());
		return new ResponseEntity<ResponseDto>(response, HttpStatus.CREATED);

	}

	@PostMapping(value = "/user/register")
	private ResponseEntity<User> UserDetails(@Valid @RequestBody User user) {
		User userResponse = userservices.addUserDetails(user);
		return new ResponseEntity<User>(userResponse, HttpStatus.CREATED);

	}

	@GetMapping("/userdetails")
	public ResponseEntity<ResponseDto> getAllUser() throws UserDetailException {
		List<User> userResponse = userservices.getAllUser();

		return new ResponseEntity<ResponseDto>(new ResponseDto(new Timestamp(System.currentTimeMillis()),
				HostelServicesConstants.SUCCESS, userResponse), HttpStatus.OK);

	}

	@GetMapping("/user/{userId}/hosteldetails")
	private ResponseEntity<ResponseDto> getHostelDetails(@PathVariable() long userId)
			throws UserDetailException, HostelNotFoundException {
		List<Hostel> response = userservices.getHostelDetails(userId);
		return new ResponseEntity<ResponseDto>(
				new ResponseDto(new Timestamp(System.currentTimeMillis()), HostelServicesConstants.SUCCESS, response),
				HttpStatus.OK);

	}

	@PostMapping("/user/{userId}/hosteldetails")
	private ResponseEntity<Hostel> hotelDetailEntry(@Valid @RequestBody Hostel hostel,
			@RequestHeader(value = "Authorization", required = false) String token, @PathVariable long userId)
			throws Exception {
		Hostel response = userservices.hotelDetailEntry(token, userId, hostel);
		return new ResponseEntity<Hostel>(response, HttpStatus.CREATED);

	}

	@PutMapping("/user/{userId}/hostel/{hostelId}")
	private ResponseEntity<Hostel> hotelDetailUpdate(@Valid @RequestBody Hostel hostel,
			@RequestHeader(value = "Authorization", required = false) String token, @PathVariable(name = "userId") long userId,
			@PathVariable(name = "hostelId") long hostelId) throws Exception {
		Hostel response = userservices.hotelDetailUpdate(token, userId, hostelId, hostel);
		return new ResponseEntity<Hostel>(response, HttpStatus.ACCEPTED);

	}

	@DeleteMapping("/user/{userId}/hostel/{hostelId}")
	private ResponseEntity<String> removeHostelDetails(@PathVariable(name = "userId") long userId,
			@PathVariable(name = "hostelId") long hostelId) throws UserDetailException, HostelNotFoundException {
		userservices.removeHostelDetails(userId, hostelId);
		return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Hostel deleted");
	}

	@PostMapping("/user/{userId}/hostel/{hostelId}/roomdetails")
	private ResponseEntity<Hostel> hostelRoomDetailEntry(@RequestBody List<RoomDetails> roomDetails,
			@RequestHeader(value = "Authorization", required = false) String token, @PathVariable(name = "userId") long userId,
			@PathVariable(name = "hostelId") long hostelId) throws Exception {

		Hostel response = userservices.hostelRoomDetailEntry(token, userId, hostelId, roomDetails);
		return new ResponseEntity<Hostel>(response, HttpStatus.CREATED);

	}

	@PutMapping("/user/{userId}/hostel/{hostelId}/roomdetails/{roomId}")
	private ResponseEntity<Hostel> hostelRoomDetailUpdate(@RequestBody RoomDetails roomDetails,
			@RequestHeader(value = "Authorization", required = false)  String token, @PathVariable(name = "userId") long userId,
			@PathVariable(name = "hostelId") long hostelId, @PathVariable(name = "roomId") long roomId)
			throws Exception {
		Hostel response = userservices.hostelRoomDetailUpdate(token, userId, hostelId, roomId, roomDetails);
		return new ResponseEntity<Hostel>(response, HttpStatus.ACCEPTED);

	}

	@DeleteMapping("/user/{userId}/hostel/{hostelId}/roomdetails/{roomId}")
	private ResponseEntity<Hostel> hostelRoomDetailDelete(@RequestHeader(value = "Authorization", required = false)  String token,
			@PathVariable(name = "userId") long userId, @PathVariable(name = "hostelId") long hostelId,
			@PathVariable(name = "roomId") long roomId) throws Exception {
		Hostel response = userservices.hostelRoomDetailDelete(token, userId, hostelId, roomId);
		return new ResponseEntity<Hostel>(response, HttpStatus.NO_CONTENT);

	}

}
