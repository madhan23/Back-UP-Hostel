package com.hostelServices.services;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hostelServices.HostelServicesConstants;
import com.hostelServices.Util.JwtUtil;
import com.hostelServices.dao.UserRepositoryImp;
import com.hostelServices.dto.ResponseDto;
import com.hostelServices.excep.HostelNotFoundException;
import com.hostelServices.excep.UserDetailException;
import com.hostelServices.models.Hostel;
import com.hostelServices.models.RoomDetails;
import com.hostelServices.models.User;

@Service
public class UserImplServices implements UserServices {

	@Autowired
	UserRepositoryImp userRepositoryImp;

	@Autowired
	JwtUtil jwt;
	
	@Override
	public ResponseDto userLogin(String mailId, String password) throws UserDetailException{
	
		User userdetails  = userRepositoryImp.userLogin(mailId,password);
		String jwtToken = 	jwt.generateToken(userdetails.getUserName()+" "+userdetails.getMailId());
	
		return new ResponseDto(new Timestamp(System.currentTimeMillis()), HostelServicesConstants.SUCCESS, jwtToken,HostelServicesConstants.LOGINED_SUCCESS);
	}

	public User addUserDetails(User userDetails) {
		return userRepositoryImp.addUserDetails(userDetails);
	}

	public List<User> getAllUser() throws UserDetailException {

		List<User> userList = userRepositoryImp.getAllUser();
		if (userList.isEmpty())
			throw new UserDetailException(HostelServicesConstants.NO_USERS_FOUND);
		return userList;
	}

	public List<Hostel> getHostelDetails(long userId) throws HostelNotFoundException, UserDetailException {

		List<Hostel> hostelList = userRepositoryImp.getHostelDetailsObj(userId);
		if (hostelList.isEmpty())
			throw new HostelNotFoundException(HostelServicesConstants.NO_HOSTELLIST_FOUND);
		return hostelList;
	}

	
	public Hostel hotelDetailEntry(String token,long userId, Hostel hosteldetails) throws Exception {
		Hostel hostel=null;
		if(validateToken(token)){
			 hostel =userRepositoryImp.hotelDetailEntry(userId,hosteldetails);	
		}
				return hostel;
		
	}

 
	private boolean validateToken(String token) throws UserDetailException {
		
	if(token!=null && !token.isEmpty()) {
		// Avoid Bearer reading token
	String jwtToken=token.substring(7);
	String username = null,userId =null;
	String []userInformation = jwt.extractUsername(jwtToken).split(" ");
	if(userInformation.length>1) {
		username = userInformation[0];
		userId = userInformation[1];
		return jwt.validateToken(jwtToken, username);		
	}
	
	}
	else
		throw new UserDetailException(HostelServicesConstants.AUTHORIZATION_HEADER);
		
	return false;
	}

	public Hostel hostelRoomDetailEntry(String token,long userId, long hostelId, List<RoomDetails> roomDetails) throws Exception {
		Hostel hostel=null;
		if(validateToken(token))
		 hostel =userRepositoryImp.hostelRoomDetailEntry(userId,hostelId,roomDetails);	
		
			return hostel;
	
	}


	public Hostel hotelDetailUpdate(String token,long userId, long hostelId, Hostel hostel) throws Exception {
		Hostel hostelObj=null;
		if(validateToken(token))
		 hostelObj =userRepositoryImp.hotelDetailUpdate(userId,hostelId,hostel);	
			return hostelObj;

	}



	public Hostel hostelRoomDetailUpdate(String token,long userId, long hostelId,long roomId, RoomDetails roomDetails) throws Exception {
		Hostel hostel=null;
		if(validateToken(token))
		hostel =userRepositoryImp.hostelRoomDetailUpdate(userId,hostelId,roomId,roomDetails);	
			return hostel;

	}



	public Hostel hostelRoomDetailDelete(String token,long userId, long hostelId, long roomId) throws Exception {
		Hostel hostel=null;
		if(validateToken(token))
		 hostel =userRepositoryImp.hostelRoomDetailDelete(userId,hostelId,roomId);	

			return hostel;
	
	}


	@Override
	public void  removeHostelDetails(long userId, long hostelId) throws UserDetailException, HostelNotFoundException {
		userRepositoryImp.removeHostelDetails(userId,hostelId);
	
	}







	
	
}
