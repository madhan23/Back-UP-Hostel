package com.hostelServices.services;

import java.util.List;

import com.hostelServices.dto.ResponseDto;
import com.hostelServices.excep.HostelNotFoundException;
import com.hostelServices.excep.UserDetailException;
import com.hostelServices.models.Hostel;
import com.hostelServices.models.RoomDetails;
import com.hostelServices.models.User;

public interface UserServices {

	public User addUserDetails(User userDetails);

	public List<User> getAllUser() throws UserDetailException;

	public List<Hostel> getHostelDetails(long userId) throws UserDetailException, HostelNotFoundException;

	public Hostel hotelDetailEntry(String token, long userId, Hostel hostel) throws UserDetailException, HostelNotFoundException, Exception;

	public Hostel hostelRoomDetailEntry(String token, long userId, long hostelId, List<RoomDetails> roomDetails) throws UserDetailException, HostelNotFoundException, Exception;

	public Hostel hotelDetailUpdate(String token, long userId, long hostelId, Hostel hostel) throws UserDetailException, HostelNotFoundException, HostelNotFoundException, Exception;

	public Hostel hostelRoomDetailUpdate(String token, long userId, long hostelId, long roomId, RoomDetails roomDetails) throws UserDetailException, HostelNotFoundException, Exception;

	public Hostel hostelRoomDetailDelete(String token, long userId, long hostelId, long roomId) throws UserDetailException, HostelNotFoundException, Exception;

	public void removeHostelDetails(long userId, long hostelId) throws UserDetailException, HostelNotFoundException;

	public ResponseDto userLogin(String mailId, String password) throws UserDetailException;
}
