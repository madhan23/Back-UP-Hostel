package com.hostelServices;

public class HostelServicesConstants {
	
public static final String INVALID_USER_ID = "Invalid UserID";

public static final String INVALID_HOSTEL_DETAILS ="Invalid HostelID";

public static final String INVALID_ROOM_DETAILS = "Invalid RoomId";

public static final String INCORRECT_USERNAME_OR_PASSWORD = "Incorrect mailId or Password";

public static final String LOGINED_SUCCESS = "Logined Success";

public static final String NO_USERS_FOUND = "No Users Found";

public static final String NO_HOSTELLIST_FOUND = "No HostelList found for these user";

public static final String SUCCESS= "Success"; 

public static final String FAILURE = "Failure";

public static final String AUTHORIZATION_HEADER = "Authorization header is missing";

}
